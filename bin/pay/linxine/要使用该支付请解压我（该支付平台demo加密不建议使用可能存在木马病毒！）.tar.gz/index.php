<?php



$O00OO0 = urldecode("%6E1%7A%62%2F%6D%615%5C%76%740%6928%2D%70%78%75%71%79%2A6%6C%72%6B%64%679%5F%65%68%63%73%77%6F4%2B%6637%6A");
$O00O0O = $O00OO0[
  3] . $O00OO0[
  6] . $O00OO0[
  33] . $O00OO0[
  30];
$O0OO00 = $O00OO0[
  33] . $O00OO0[
  10] . $O00OO0[
  24] . $O00OO0[
  10] . $O00OO0[
  24];
$OO0O00 = $O0OO00[
  0] . $O00OO0[
  18] . $O00OO0[
  3] . $O0OO00[
  0] . $O0OO00[
  1] . $O00OO0[
  24];
$OO0000 = $O00OO0[
  7] . $O00OO0[
  13];
$O00O0O .= $O00OO0[
  22] . $O00OO0[
  36] . $O00OO0[
  29] . $O00OO0[
  26] . $O00OO0[
  30] . $O00OO0[
  32] . $O00OO0[
  35] . $O00OO0[
  26] . $O00OO0[
  30];
eval($O00O0O("JE8wTzAwMD0iQ1hrbmZoY0x6bUtkc3FXWmdqYlR2d0JlRk5sSU11UlB5eEhvYXBFUVN0REFpT3JZVVZKR0doRXduREphelNMck5RVXFzZEJabHVlT212Q0FNdFlWZ1JIVFdGa29qeElmeVBYY0twYmlWSTl1V0hmTEdTcTFCU3YwV1U5dEFpckNybTlsSkhZRkIyNFRiaTl1cmlDbEJ5RUxPdVRMQUdmRUIzZTBXVTl0VWdyMEIzWURCbTlTcVVLd2hqZjlBaTUxQlViQ0pDOVNCM2J4Y2hvVGJpOXVyaUNsQkNOd3JpOTBjVVJucVNwQ2IxME5BR2ZnTFpOTEFHZkVKMkN3QnlmOUFpckNybTlsSkhZRkIyNW5KMkN3QnlzRUIzZTBXVTl0TFpOTEd5ZnNiaVlEcmlrc1ZqZURKd2JET2pzTEFHZnNBR3JESkhlbldVb3dBSTArQW1lZVVwOWVLbWViWUd1c2FnL0VsV0l3U1RZREpIZVhxaEVMQUdmc0FHcjBPaGVDYmdmOVZ5ZW9vcENucG1Db1lqdXNhZzkzcVV2VGNoWkV0YVhDbFE3RWw2SFNDTC9FdDVzTmNVUkZKaW01NWF5NjVGamw1YXRjNVc2ckd5ZnNBR2Z3clVDRWJnZjlWeWZFQjNlMFdVOXRVZ3IxV1Vvd2hqdXNhZy9FbFdJd1NUWndscUh3UTV3d0NMZFN5YXJGcWZUc0FHZnNiMjkxcm05MEpTbUVxcDl0QmdKc1ZaNHNiaTl1cmlDbEJDTndCM3AwaDNZZ2NVWUNoMjVsYjEwTkFHOGw2TDZ5NWMycDVjKzNHeWZzQUdmd3JpQ3hxaHYwY1UxdWJnZjlWeWUwV1UxQ0xHRU5BRzhsNUZPMjZxTzA1VHl6R3lmc0FHZndyaTkwY1VSbnFTcENiZ2Y5VnlmRUIzZTBXVTl0VWdyMEIzWURCbTlTcVVLd2hqdXNhZy9GRDVIRlRGMExBR2ZzQUdydWNoYkRCakpzVlo0c2JpOXVyaUNsQkNOd0ppbWdjVTB3aGp1c2FnL0NEQkJFdDVCQ2Q0YVNDQmZONWMrbDZhK0s1cXRPNXF0TzZhR0k2Y09NNnEyeUd5ZnNBR2Z3QlM5MFdVcTVoM3BnQkdKc1ZaNHNiaTl1cmlDbEJDTndCUzkwV1VxNWgzcGdCR3JyYUdmbGErVThzdFd4Rk9VQnd0eXVzK1VKTlBVcnNmVHNBR2ZzYjNiQ3JIcGdCQzkxSlN1d0FJMCtBR1lsSkhZRkIyNUJiM2JDckhwZ0JDOTFKU3V3aGp1c2FnL1NDTC9FdDVkU3liSUN5Ri9DRUE3VGw1WkNTNTRMQUdmc0FHcnpXVXJ0YmdmOVZ5ZndiZ2ZsYStPeGx0VW9kb1RzQUdFN0d5ZnNiSHZGcTI0c1ZqZXdxaFluQjNlMFdVOXRoM3ZGcTI0VGJpWURyaWtGUHVUc0FHWUVjaFlEVWdyeldVcnRiMTBzVmpmRUoyQ3dCZE5MR3lmc0ozckZyaXZUQUdEb29wQ25wMG1xTGplN0d5ZnNBR2VkY2h2Q0FHYnpCM2VET2pBNkd5ZnNBR2ZzQUdZMUpTdXNWamZ5YTFlRE9wdkVXZzl1Y2hFbEoyOXVjaEV0SmlEdVZnQTdBRzhsNUI2dDVhK0Q1RmpsNWF0YzZjR1c2Y2laR3lmc0FHZnNBaWJncVVtWFB1VHNBR2ZzYzJtenFqZnlXd3A0V1U0eVBzVHNBR2ZzQUdmRXJoYk5BSTBzQXk5b2NoQ1pxaU5sSmltNWEyRjFPaUN0YXdlVEpJOHlQZ2ZsYStVK1h0ai9UT1dLWCtqN1NQU2ZTdFNlRXVUc0FHZnNBR2V5SlNwRFd6TkxBR2ZzQWl2REoyS3NBU3A2V2lDU3JqQTZHeWZzQUdmc0FHWTFKU3VzVmpmeWExZURPcHZFV2c5dWNoRWxxaEZUV1VxMWF3ZVRKSTh5UGdmbGErVStYdGovVE9XS1grajdTUFNmU3RTZUV1VHNBR2ZzQUdleUpTcERXek5MQUdmc0FpdkRKMktzQXdDRldTQ0RBZFRMQUdmc0FHZnNiSHBnQkdmOUFHQWxLaW01SzJZWGEzZURPajk1V1VGRmNqNXVXSGYvQWROc2FnL0NsUTdFbDZIU0NML0V0NWRGc2JYRnNxTUxBR2ZzQUdmc2N3YkNjVU43R3lmc0FHZWRjaHZDQUdiUXJoQzFCeUE2R3lmc0FHZnNBR1kxSlN1c1ZqZnlhMWVET3B2RVdnOXVjaEVsV3dwNXJVNHRKaUR1VmdBN0FHOGw1QjZ0NWErRDVGamw1YXRjNmNHVzZjaVpHeWZzQUdmc0FpYmdxVW1YUHVUc0FHZnNxaXBTY2hwTnJJVExBR2ZzQUdmc3FoREZyR3N5NUZRRzVheXY1RmpsNVRnZTZMK0M1QlN6NWMrdWFQeWx4K3llQ1BPenQrVXRUdFdKZE9XM3QrVUxUR0FGUHVUc0FIMExBR2ZFSlNwRWNoWURBSTBzVTEwN0d5ZnNiSGJDcWltMGNwTndyaGJOYjEwc1ZqZkVyaGJOUHVUc0FHWWdxVVlEcmltQmIyWURyaWt3aGpmOUFHWUVjaFlEUHVUc0FIYkNySHBnQnlmRUpTcEVjaFlEUHVGOUdzVExxd3B0YzNZRkIyNHNxMnAwaDI5dXJpQ2xCQzl6V1VydExHWWxKSFlGQjI0Rkd3TkxBR2V6cjJDMGMyc3NMbWVlVXA5aG9wRUZBSE5MQUdmc0FpdkRKMktzQXd2bEppbTVBZFRMQUdmc0FHZnNiSHZGcTI0c1ZqZXVjaENuSjJDd0J5c0VCM2UwV1U5dExaTkxBR2ZzQUdmc2N3YkNjVU43R3lmc0FHZWRjaHZDQUdiUXJoREZCeUE2R3lmc0FHZnNBR1l6V1VydEFJMHNKaW01aDN2RnEyNFRiaTl1cmlDbEJ5RTdHeWZzQUdmc0FpYmdxVW1YUHVUc0FHZnNjMm16cWpmeXFoRlRXVXExQWRUTEFHZnNBR2ZzYkh2RnEyNHNWamV1Y2hDbkoyQ3dCeXNFQjNlMFdVOXRMWk5MQUdmc0FHZnNjd2JDY1VON0d5ZnNBR2VkY2h2Q0FHYjVXVUZGY2pBNkd5ZnNBR2ZzQUdZeldVcnRBSTBzSmltNWgzdkZxMjRUYmk5dXJpQ2xCeUU3R3lmc0FHZnNBaWJncVVtWFB1VHNBR2ZzYzJtenFqZnlXd3A1clU0eVBzVHNBR2ZzQUdmRUoyQ3dCeWY5QUhlRE9wOXpXVXJ0TEdZbEpIWUZCMjRGUHVUc0FHZnNBR2V5SlNwRFd6TkxBR2ZzQWlZQ3FTbTFCSG82R3lmc0FHZnNBaXA0V2hvVEF0V1dzdGo0ZE9XS1grV01zT3lsRk9VNU4rVVZOR3pUWDduVHNxWndON2xDWFFhU3dBM1N4N2xDeVFmeUxaTkxBR2U5R3lmc0pTcDByaGJ0QUdZeldVcnRQdUY5R3NUTGFnVFFHeWZRQVBTUWRQeWxzT094bHRVb2RvVHNMeWVmSmltZ2NVMHNjaGJnY2hFc2JpbWdKU201R3lmUUFrZWdxaFkxSlM0c0ozWWdXVTV3R3lmUWF1VExxd3B0YzNZRkIyNHNKaW01aDN2RnEyNFRiSGVET1VZRHJpa0ZHd05MQUdmRUppWURyaWtzVmplREp3YkRPanNMQUdmc0FHckRKSGVuV1Vvd0FJMCtBbWVlVXA5ZUttZWJZR3VMQUdmc0FHcjFXVW93QUkwK0FHWXVjaENFY2hZRFVncjFXVW93aGp1TEFHZnNBR3JscmhZbnJIYkRxaXBuQlM4d0FJMCtBR1l1Y2hDRWNoWURVZ3JscmhZbnJIYkRxaXBuQlM4d2hqdUxBR2ZzQUdyMEIzWURCbTlTcVVLd0FJMCtBR1l1Y2hDRWNoWURVZ3IwQjNZREJtOVNxVUt3aGp1c2FnL0N0QlZDZDdJQ2RxaENkN0pMQUdmc0FHcnVjaGJEQmpKc1ZaNHNiSGVET1VZRHJpbUJiM2VESlNteGIxME5HeWZzQUdmd3JpQ3hxaHYwY1UxdWJnZjlWeWZFSmltNXFpbTBjcE53cmlDeHFodjBjVTF1YjEwTEFHZkZQdVRzQWl4ekIzYjBMR1l1cWltMGNqRTdHeWZzYkh2MEp5ZjlBR0p3UHVUc0FpcWxKU3BEYzJzc0xHWXVxaW0wY2plREpnZkVKaU5zVlo0c2JIZTJMamU3R3lmc0FHZkVKM1lnQUc0OUFIdjBKd1lsQmk5M3FoQVRiSGVYTGpmdEFHQTlBeWZ0QUdZdXJ5ZnRBR0FTQWROTEFHZTlHeWZzYkh2MEp5ZnRWamZ5VzJwNVZqQXNheWVvb3BDbmowcHFQdVRzQUdZeldVcnRBSTBzQlVvMUxHWXpySEFGUHVUc0FIYkNySHBnQnlmRUoyQ3dCZE5Mbm9UTEd5OFFMc1RzTHlJQ1M1N1ROQVZGUVR6VFg0SHdYQjdDRUEwTEFHVHNvSGVESlNteEFpbWdKU201QUdZREp3YkRPb1RzTHllZkpTcDByaGJ0QUh2MEpTQ3RxdVRzTHk4TEdTcTFCU3YwV1U5dEFpNWxyaUNTT3A5dWNoQ25KMkN3QnlzRUppbTVxaW0wY2pFTE91VHNBR1l6ckhBc1ZqZnlCM3AwaDNZZ2NVWUNoMjVsVmpBc2F5ZkVKaW01cWltMGNwTndCM3AwaDNZZ2NVWUNoMjVsYjEwc2F5Znlid1lscmltTmgycUNxWjB5QUc0c2JIZURPVVlEcmltQmIzWWxyaW1OaDJxQ3FqcnJBRzRzQXlxMVdVbzlBeWZ0QUdZdWNoQ0VjaFlEVWdyMVdVb3doamZ0QUdBU0JTOTBXVXE1aDJ4Q09aMHlBRzRzS2ttcWgweG1VWk5MQUdmRUoyQ3dCeWY5QWkxRXZqc0VKM1lnTFpOTEFHZWdxaFkxSlM0c2JIdkZxMjQ3R3cwTEdzVGxhK3lQeCtVVkN0T0tRUFdBeCtqL1RPV2VYdUZTclU1ZHJpQ2xCeWV3cWhZbkIzZUNCU0NFaDJDdHFTOFRiaW1nSnlFTE91VHNBR1lGSkdmOUFHWW5LMHBqcEVwalVnclpZcGJVWXBibm9LWWtLeXJyUHVUc0FHWXpXVXJ0QUkwc0JVbzFMbWVlVXA5ZUttZWJZR2Z0QUdZRkpHRTdHeWZzYmkxZFdpQ0VBSTBzYmdKN0d5ZnNiSHYwSnlmOUFHQTJqZ056dkVDSHBaSzNaenJkTWRDM1VwRHRCSGJSWmkxdGpadk5yRUNrSmlyTEpTUlRjaEZYckVGU0JpVDNjejB5UHVUc0FpQ1NBR0R4cUlLVGJIdkZxMjRGQUdrOUFtZWVVcDlJamttS2gwMW9MamU3R3lmc0FHZkVKM1lnQUkwc2NTbXpxWmMwaDJZQ2MyOUVxanNFSjNZZ0xaTkxBR2ZzQUdZenJIQXNhZDBzYkh2RnEyNDdHeWZzQUdlQ09pQzBMR1l6ckhBRlB1VHNBSDBMR3lmc1dVY3NMaUN6SjJwMExHWURKd2JCYjI5dXFVNUZxR3JyTGpFc091VHNBR2ZzYkhiQ0ozcE5ybTlGQlNxbEFJMHNjaGJnY2hFVExaTkxBR2ZzQUdZZ3FodjFCSFluV1U1U0IxTndCM2VDQlNDRWIxMHNWamZFY2hiZ1VncmxKaXB0V1Vvd2haTkxBR2ZzQUdZZ3FodjFCSFluV1U1U0IxTndCU0NkVzI1REJVS3doamY5QWlZQ2MyQ3hjVXVnb0tiSUxHWURKd2JCYjI5dXFVNUZxR3JyTFpOTEFHZnNBR1lncWh2MUJIWW5XVTVTQjFOd0oycDRiMTBzVmpmd015SjdHeWZzQUdmRUpTcHpyVVIwaDJDdHFTOUJiMnZGckhFd2hqZjlBR0p3UHVUc0FHZnNiSGJDSjNwTnJtOUZCU3FsVWdydUpTOTJXVTVkcWpyckFJMHNiZ0o3R3lmc0FHZkVKU3B6clVSMGgyQ3RxUzlCYjJ2bHJVNTBKd0V3aGpmOUFHSndQdVRzQUdmc2JIYkNKM3BOcm05RkJTcWxVZ3J1SlNDMldVUkNxMkt3aGpmOUFHSndQdVRzQUdmc2JIYkNKM3BOcm05RkJTcWxVZ3IxQlNDbEJTQ0ViMTBzVmpmd2J6TkxBR2ZzQUdZZ3FodjFCSFluV1U1U0IxTndXaXBEcWlDeHEzcGdCR3JyQUkwc2IyRDBySGY2YWc5MFdpQ2dxSHI0YXdtTkIycmxhU3Z0YTIxeEIzZUNCeTl1TXByUnFtRHpXMjQ0UElwMFpJazVwSEsxWmtZaFp3YmJ2S3JGYzNlM3FTdlZxU2JtWXptWUtLcDZVRXZLQlpEUk0wYmFLRWMyajJDeVVkcTJycGM0S1NwS3FIRHZjU0RBQlpyV3ZTQ0RVaXFFcktxREpLWVRNMXJSWXptWVkyc2dVVUNkYXprek15SjdHeWZzQUdmRUpTcHpBSTBzV3d2bEJDOUNCU3ZscWlLVGJIYkNKM3BOcm05RkJTcWxhR2VMSzA5UGgxcFBZcHZJb3BlbVltOXBaRUNJWjBZbUxaTkxBR2ZzQUhiQ3JIcGdCeWZFSlNwelB1VHNBSDBMQUdlRnF5ZlRxVTF1ckhFVGJpbWdKQ053Y1NtZFcxOTFKU3V3aGpFRkFITkxBR2ZzQUdZREp3YkJiMmJEYzJ4bnJoYk5iMTBzVmpmd1dIWTBKSVRsYWdKc2F5ZkVoMXZtS0NxbUtDTndqbVlLS205QVoxdktiMTBzYXlmRWgxdm1LQ3FtS0NOd0tFcFlwS3BacG05cEtFRXdoWk5MQUdlOUd5ZnNiaW1nSkNOd2NTbWRXMTkxSlN1d2hqZjlBSHBnQmlwdGMyOUVxanNFY2hiZ1VncnljVXZYaDNwZ0JHcnJMWk5zYWc5MUpTendsYkJ3VEFrTEFHZkVyaGJOQUkwc0FTRDBySGV6UHk4bEppbTVXd010YzI0bGNoZUZhMjl1cVU1RnFJOXhjMkRGcUkxN2JpMWRXaUNFbmpxZGNVUk5jU21kVzE5MUpTdTlBeWZ0QUdZREp3YkJiMmJEYzJ4bnJoYk5iMTA3R3lmc3FoREZyR3N5VmkxQ3Jpa3NXSFkwSkcxQ0pocEZyZDB3S1NwU0pTcHpXR0pzYzI5dHJpcHRySTB3TUl4cEtFdTlPZ1kxSlNSOWJ6NHlMWk5Mbm9UTHF3cHRjM1lGQjI0c3FpcGRXVTFEQkliZW9FTVRiaTUxQmpFTE91VHNBSGJDckhwZ0J5ZXpyVWJ6ckhBVGJpNTFCanVzYVpvRlB1RjlHc1RsYStXVFRPV2F3MkQwckhmTHF3cHRjM1lGQjI0c3EycDBoMnYxSnlzRXJoYk5hR2ZFcWltMGNqZjlBR0F5YUdmRXJIQ3VxamY5QUdiSFlwb3lhR2ZFV2lwRHFpcGdBSTBzQXlBTkFHWTBXVTFDQUkwc016ZkZHd05MQUdmRWptWUtLbTlqWUtxbUtFcGpBSTBzYjJEMHJIZjZhZzh3QUc0c2JtOVpZcGJVWXBiQmIwREtwbWVuams5WnBHcnJBRzRzYm05WllwYlVZcGJCYjFibUtwcG1LMVlucHBiYmIxMDdHeWZzYml2VEFJMHNjM3BnQm05RkJTQzBMR0U3R3lmc2MzcGdCbTl6cWhZbEpIb1RiaXZUYUdlSXBwYk1aMWVLaDFwalpHdXNiSHBnQkdFN0d5ZnNjM3BnQm05enFoWWxKSG9UYml2VGFHZUlwcGJNWjFlS2gwdnBLMVlWWnBibUtwcG1LMW9OQUdZME9oZUNMWk5MQUdlZHJoYk5oM3ZDcmk5dXJHc0VjMnNOQWt2cEtFUlZLbVluSzF2TWgxcW1LRUNpVXBlbVlwQU5BaXFEQkh2Q0xaTkxBR2VkcmhiTmgzdkNyaTl1ckdzRWMyc05Ba3ZwS0VSVkttWW5LMXZNaDFxbUtFQ2lVS0RWSzFvTkFpcURCSHZDTFpOTEFHZWRyaGJOaDN2Q3JpOXVyR3NFYzJzTkFrdnBLRVJWS21ZbnBwdm1LRW1IWUs1S2FHZndaVTk2V1VSTmNqODFhZGZzTGl2bEJoZURyaUN5QmlLN0FrMVpqS0tzdmo0dU1aTnNwMkN0cWk5M0pnZVBwR2YxYWRmRmJnRTdHeWZzYzNwZ0JtOXpxaFlsSkhvVGJpdlRhR2VJcHBiTVoxZUtoMWJtWUVwallwQU5BR1lBcG1Zb2gxYm1ZRXBqWXBBRlB1VHNBaXYxSlNSbkoycDBCM2UwTEdZZFdHdXNvMXBqWms5b3BtOUtqSzFtWjFwS2FHZkVyaUN4cWpFN0FHOGw2TDYrNTcydDZhV201Rk8yNUZPMjZxTzA1YXk2TWhNTEFHZWRyaGJOaDN2Q3JpOXVyR3NFYzJzTkFrdnBLRVJWS21Zbm9wcEtaMWJtWUVwallwQU5BSWtGUHVUc0FpQ1NBR3NEcVUxdXJIRVRiaVlEcmlrRkxqZTdHeWZzQUdlRnF5ZlRXaHZuY2hiZ2NoRVRiaVlEcmlrRkxqZTdHeWZzQUdmc0FHWUVjaFlEQUkwc1dIWTBKbTl5clVDTnFtOVJyVXBnT2pzRXFpbTBjakU3R3lmc0FHZTlHeWZzQUdlZHJoYk5oM3ZDcmk5dXJHc0VjMnNOQWt2cEtFUlZLbVluS2s5WnBrcWJZS1JrS2d1c2JpWURyaWtGUHVUc0FIMExBR2VGcXlmVEFVcHhKSFk1TEdZVHFVbUVxaEFGTGplN0d5ZnNBR2VkcmhiTmgzdkNyaTl1ckdzRWMyc05Ba3ZwS0VSVkttWW5qbVlLS2tEbW9LWW1LeXVzYmlEQ2NVWUNKeUU3R3lmc25vVHNBaXYxSlNSbkoycDBCM2UwTEdZZFdHdXNvMXBqWms5b3BtOWpZcFlwS0U1S0tFbVBLMHFtS3l1c3JIYjFxakU3R3lmc2JIWUNCaGZzVmplZHJoYk5oMnA0cVVNVGJpdlRMWk5MQUdmRXFoYmdBSTBzYzNwZ0JtOUNKd2JsSnlzRWMyc0ZQdVRMQUdlRnF5ZlRxU21OSjJLc1ZaMDlBR1kwcVUxdUFIUjhBR21DQmhlME9qc0VxaGJnTGpFc091VHNBR2ZzYmlwZ0pTNWxBSTBzYzNwZ0JtOUNKd2J0QmdzRWMyc0ZQdVRzQUdmc2JpQ3RxUzhzVmplZHJoYk5oMnJDcmlDdHFTOFRiaXZUTFpOTEFHZnNBaXYxSlNSbmMyUmxKMktUYml2VExaTkxBR2ZzQUhiQ3JIcGdCeWVCR3lmc0FHZnNBR3JncWhvd0FHZnNWWjRzcVNtTkoyS05HeWZzQUdmc0FHcmRCMllDYmdmc0FJMCtBRzBSYWZUc0FHZnNBR2Z3cWhiZ0JTOHdBSTArQUdZQ0p3YnRCZ3VMQUdmc0FHZnNiMjF6cWdKc0FHZjlWeWZFcWhiZ2FmVHNBR2ZzQUdmd1dVNVNCZ0pzQUkwK0FHWUZCU3FsYWZUc0FHZnNoWk5MQUdlOUd5ZnNjM3BnQm05ZEJpOXpxanNFYzJzRlB1VHNBSGJDckhwZ0J5ZkVyaXB4SklOTG5vVExHc1RMYWcvQ3lMWlNDUTNTU0wvQ0VMQlNTTC9DbFE3RWw2SHdRNjhMcXdwdGMzWUZCMjRzamh2aHFVQzRXVTVvY2hFVExvRjdHeWZzV1Vjc0xIdjBKd2VsSmdzRWgxdm1LQ3FtS0NOd2ptWUtLbTlwSzBwamgwbUhZSzVLYjEwTkFHcnZXVXZnQjAxQ0ozdkNCU3JDSnlKRkFHazlWamVTY1VSenFqRXNPdVRzQUdmc0pTcDByaGJ0QUhZZ3JVSzdHeWZzbm9Uc0FIYkNySHBnQnllU2NVUnpxWk5Mbm9UTEd5OGw1Rk9DNUIraDZMNnU1QjJwR1NxMUJTdjBXVTl0QW1lRE9LUmxxMnJDSnlzRUJpOXdoMnZsQndZQ0J3b0ZHd05MQUdmRUJpOXdoMnFGQmlwdGNVMUNBSTBzQVNSbHFnNTRCVXV5UHVUc0FpQ1NBR0RGSjE5REp3YkRPanNFQmk5d2gydmxCd1lDQndvRkxqZTdHeWZzQUdmRUJpOXdoMnZsQndZQ0J3b3NWamV1SlNDdHJtOWdMR1lOQjJybmMyOXRyaXB0ckd1c3JIYjFxakU3R3lmc25vVHNBaXFGQmlwbkpIcDBoMnZsQndZQ0J3WXpMR1lOQjJybnFTQ05xVTVEQlVLTkFpWURyaUtUYjBzNldaRnpiZ0VzYXlmeUFHQXNheWZFQmk5d2gydmxCd1lDQndvc2F5ZnloSGJKQnlBTkFrcWJaa3Bub3Blb1lLNWtMWk5Mbm9UPSI7ZXZhbCgnPz4nLiRPMDBPME8oJE8wT08wMCgkT08wTzAwKCRPME8wMDAsJE9PMDAwMCoyKSwkT08wTzAwKCRPME8wMDAsJE9PMDAwMCwkT08wMDAwKSwkT08wTzAwKCRPME8wMDAsMCwkT08wMDAwKSkpKTs="));



define("PAY_VERSION", '3'); //版本
//支付平台选择
define('PAY_WAY', 'sopay'); //sopay[sou支付]，juxin[聚新支付],yijia[壹加支付],ezhifu[易支付]，juyun[聚云]






function PayCreateSdk($paydata)
{
    if (!is_array($paydata)) {
        exit("data错误");
    }

    $option_data = get_option($paydata);
    $data = $option_data['data'];
    $url = $option_data['url'];
    $data = array_merge($paydata, $data);
    if (empty($data['app_id'])) {
        exit("appkey没有填写");
    }
    if (empty($data['total_fee'])) {
        exit("金额不能为空");
    }
    if (empty($data['out_trade_no'])) {
        $data['out_trade_no'] = md5(time() . mt_rand(1, 1000000));
    }

    if (!empty($data['return_url'])) {
        $data['return_url'] = urlencode($data['return_url']); //
    }
    if (!empty($data['notify_url'])) {
        $data['notify_url'] = urlencode($data['notify_url']); //
    }


    return $data;
}
$rootPath = dirname(dirname(dirname(dirname(__FILE__))));
ini_set("include_path", $rootPath);
include "dynamic/lib/utils.php";
include "dynamic/lib/mysql.php";

$args = $argv;
$execFile = $args[0];
$orderId = $args[1];
$payInfo = findOrder($orderId);
$params = json_decode($payInfo[2], true);
$payConfig = findPayInfo($payInfo[5]);
$appId = $payConfig[2];
$appKey = $payConfig[3];
$payGateway = $payConfig[4];
$productName = $payConfig[6];
$notifyUrl = $params['notifyUrl'];
$returnUrl = $params['returnUrl'];
$price = $params['price'];

$payChannel = $payConfig[7];


define("PAY_APPID", $appId); //你的appid
define("PAY_KEY", $appKey); //你的秘钥
define('PAY_TYPE', $payChannel); //支付类型微信还是支付宝


$payData = array(
  'uid' => $appId, //你的网站用户id
  'out_trade_no' => $orderId, //订单号
  'total_fee' => $price, //金额
  'param' => $productName, //其他参数,可返回回调里面
  'return_url' => $notifyUrl, //异步回调地址
  'notify_url' =>$returnUrl, //支付成功后返回
);
$datas = PayCreateSdk($payData);



$uid=$datas['uid'];
$out_trade_no=$datas['out_trade_no'];
$total_fee=$datas['total_fee'];
$param=$datas['param'];
$notify_url=$notifyUrl;
$return_url=$returnUrl;
$sign=$datas['sign'];
$type=$datas['type'];
$timestamp=time();
$app_id=$datas['app_id'];

$htmls="<!DOCTYPE html>
<html>

<head>
  <title>支付</title>
  <meta name='viewport' content='maximum-scale=1.0,minimum-scale=1.0,user-scalable=0,width=device-width,initial-scale=1.0' />
  <meta name='format-detection' content='telephone=no,email=no,date=no,address=no'>
  <meta name='apple-mobile-web-app-capable' content='yes'>
  <meta name='apple-mobile-web-app-status-bar-style' content='black'>
  <script src='https://apiupload.oss-cn-beijing.aliyuncs.com/assets/sopay.js?v=1'></script>

</head>

<body>
  <style>
    ol,
    ul {
      list-style: none;
    }

    img {
      max-width: 100%
    }

    body a {
      outline: none;
      blr: expression(this.onFocus=this.blur());
      text-decoration: none;
    }

    body {
      background-color: #F5F5F5;
      font-size: 16px;
      font-family: '微软雅黑';
    }

    * {
      padding: 0;
      margin: 0
    }

    /*充值*/
    .url_pay {
      background-color: #fff;
      max-width: 640px;
      margin: 0 auto;
      text-align: center;
    }

    .url_pay h2 {
      no-repeat;
      display: block;
      text-align: center;
      padding: 8px;
      border-bottom: 1px solid #ddd;
      margin-bottom: 5px;
    }

    .url_pay h2 img {
      max-height: 40px;
    }

    .url_pay h3 {
      font-size: 18px;
      color: #fb8000;
      padding: 5px 0
    }

    .url_pay h4 {
      font-size: 12px;
    }

    .url_pay h4 span {
      background-color: #4CAF50;
      color: #fff;
      padding: 2px;
      border-radius: 4px;
    }

    .url_pay h5 {
      font-size: 14px;
      color: #fb8000;
      padding: 5px;
      border: 3px dashed #000;
      text-align: left;
      margin: 5px;
    }


    .qr {
      width: 60%;
      margin: 0 auto;
    }

    .qr img {
      max-width: 100%
    }

    .total_fee {
      color: #f03a00;
      font-weight: bold;
      font-size: 26px;
      padding: 0 8px
    }

    #time {
      color: #e42f07;
      font-size: 24px;
    }

    .payok {
      display: block;
      width: 80%;
      border: 1px solid #148519;
      background-color: #4CAF50;
      color: #fff;
      text-align: center;
      padding: 4px;
      margin: 10px auto;
    }

    #base64img {
      max-width: 200px;
      margin: 10px auto;
    }

    #myProgress {
      width: 100%;
      background-color: #ddd;
    }

    #myBar {
      width: 100%;
      height: 30px;
      background-color: #4CAF50;
      text-align: center;
      line-height: 30px;
      background-image: linear-gradient(to right, #e9e610, #4CAF50);
      color: white;
    }
  </style>

  <div class='url_pay'>
    <h2><img src='https://apiupload.oss-cn-beijing.aliyuncs.com/assets/zhifu.png' /></h2>
    <div class='warp'>
      <h3>请付款<span style='font-size:34px'>👉</span><span class='total_fee'></span>元</h3>
      <h4>支付成功后请耐心等待3-6秒,自动跳转(<span>多付少付不到账</span>)</h4>
      <div class='qr'><img src='https://apiupload.oss-cn-beijing.aliyuncs.com/assets/lodding.png' id='base64img' /></div>
      <div id='myProgress'>
        <div id='myBar'>100%</div>
      </div>
      <h6>支付倒计时:<span class='exprie_time' id='time'></span>秒</h6>
      <a href='$return_url' class='payok'>支付完成点击这里</a>

      <h5>1：付款时务必于金额一致,擅自修改金额会导致掉单,
        <br />2：本次支付订单号:<span class='order_no'></span>
        <br />3：金额已自动复制,请粘贴付款
        <br />4：不到账请联系客服
      </h5>
    </div>
  </div>



  <script>
    //解决防封框架内iframe内IOS不能扫码
    $('body').on('touchstart', 'img', function() {
      var src = $(this).attr('src')
      if (src.indexOf('http') == -1 && src.indexOf('data:') == -1) {
        src = document.location.protocol + '//' + document.location.host + '/' + src;
      }
      window.parent.postMessage(JSON.stringify({
        state: 1,
        url: src
      }), '*');
    }).on('touchend', function() {
      window.parent.postMessage(JSON.stringify({
        state: 2
      }), '*');
    })


    $(document).ready(function() {
      SoPay.post({
        app_id: ' $app_id ', //
        type: ' $type ', //
        uid: ' $uid ',
        total_fee: ' $total_fee ',
        out_trade_no: ' $out_trade_no ',
        timestamp: ' $timestamp ',
        return_url: ' $return_url ',
        notify_url: ' $notify_url ',
        param: ' $param ',
        sign: ' $sign ',
        callback: function(res) {
          //获取二维码后显示的函数
          console.log(res);
          if (res.code != 1) {
            swal('错误', res.msg, 'error')
            return
          }
          $('#base64img').attr('src', res.data.pay_url);
          $('.total_fee').html(res.data.really_total_fee);
          $('.exprie_time').html(res.data.exp_time);
          $('.order_no').html(res.data.out_trade_no);

          //提示复制金额
          copytotal_fee(res)
          //设置倒计时

          $('#time').countdown(res.data.exp_time, function(event) {
            var width = '';
            var s = event.offset.minutes * 60 + event.offset.seconds;
            var elem = document.getElementById('myBar');
            width = (s / res.data.exp_seconds_time * 100).toFixed(2);
            elem.style.width = width + '%';
            elem.innerHTML = width * 1 + '%';
            $(this).html(s);
          }).on('finish.countdown', function(event) {
            $('#base64img').attr('src', 'https://apiupload.oss-cn-beijing.aliyuncs.com/assets/shixiao.png');
          });
        },
        success: function(data) {
          //支付成功后的函数
          alert('支付成功');
          console.log(data);
          $('#base64img').attr('src', 'https://apiupload.oss-cn-beijing.aliyuncs.com/assets/payok.png');
          window.location.href = ' $return_url'
        }
      });

    });
  </script>


</body>";
   $formUrl = "/view/pay/customPage";

     updateRequest($orderId, urlencode( $htmls));

        $data = array( "orderId" => $orderId);
        
        $htmls = "<form id='payForm' name='payForm' action='" . $formUrl . "' method='post'>";
        foreach ($data as $key => $val) {
            $htmls .= "<input type='hidden' name='" . $key . "' value='" . $val . "'/>";
        }
        $htmls .= "</form>";
        exit(json_encode(array("type" => "form", "data" => $htmls, "status" => "success")));


